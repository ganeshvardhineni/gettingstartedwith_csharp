﻿namespace SecureLoginApp.Views.Account
{
    public class Login
    {
    }
}
