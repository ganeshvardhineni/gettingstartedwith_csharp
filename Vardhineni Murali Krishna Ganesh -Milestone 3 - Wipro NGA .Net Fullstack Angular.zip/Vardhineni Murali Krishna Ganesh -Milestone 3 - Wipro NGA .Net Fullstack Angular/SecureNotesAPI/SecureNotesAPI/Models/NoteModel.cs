﻿using System.ComponentModel.DataAnnotations;

namespace SecureNotesAPI.Models
{
    public class NoteModel
    {
        [Required]
        public string Title { get; set; }

        [Required]
        public string Content { get; set; }
    }
}