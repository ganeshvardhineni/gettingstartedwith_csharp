﻿using System.ComponentModel.DataAnnotations;

namespace SecureNotesAPI.Models
{
    public class RegisterModel
    {
        [Required]
        [MinLength(3, ErrorMessage = "Username must be at least 3 characters.")]
        public string Username { get; set; }

        [Required]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
        public string Password { get; set; }
    }
}